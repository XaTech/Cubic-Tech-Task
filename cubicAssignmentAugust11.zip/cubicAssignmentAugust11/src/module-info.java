module superClass {
}