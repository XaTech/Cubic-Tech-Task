package sum;

public class Sum {

	
	public static void main(String[] args) {
		int a = 100;
		Double b=300.00;
		double sum = a + b;
		
		System.out.println(sum);
	}
	
}


