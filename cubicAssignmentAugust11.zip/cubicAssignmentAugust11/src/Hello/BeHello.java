package Hello;

public class BeHello extends Hello{
	String color="pink";
	String name="Yashmin";
	
	

	public void show() {
		System.out.println("name="+name);
		System.out.println("this.name="+this.name);
		System.out.println("color="+color);
		System.out.println("this.color="+this.color);
		System.out.println("super.color="+super.color);
		// call super class show()
		
		super.show();
		
	

	}

	
}
