package Hello;

public class Yelloh {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String word = "Hello";
		for (int i=0; i < word.length(); i++) {
			@SuppressWarnings("unused")
			String reverseLetter = (word.charAt(i) + "");
		}
		
	}
 
}
