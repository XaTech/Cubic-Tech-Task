package Hello;

public class Hello {
	
	String name="Deppesh";
	String color="white";
	
	public void show () {
		System.out.println("name="+name);
		System.out.println("color="+color);
		
	}

	

	}



